<div class="stm-header-search heading-font">
	<?php get_search_form(true); ?>
</div>